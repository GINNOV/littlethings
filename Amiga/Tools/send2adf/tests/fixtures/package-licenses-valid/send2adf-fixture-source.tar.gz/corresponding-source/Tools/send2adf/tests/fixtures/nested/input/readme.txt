Nested fixture root payload.
